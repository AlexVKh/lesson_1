example = "Legendary"
print(example[0])
print(example[-1])
print(example[4:])
print(example[::-1])
print(example[1::2])

